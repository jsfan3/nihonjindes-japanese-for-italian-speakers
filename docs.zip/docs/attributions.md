# Media attributions

## Correct answer sound

[https://freesound.org/people/ertfelda/sounds/243701/](https://freesound.org/people/ertfelda/sounds/243701/)

## Wrong answer sound

[https://freesound.org/people/Autistic%20Lucario/sounds/142608/](https://freesound.org/people/Autistic%20Lucario/sounds/142608/)
