# Nihonjindes LibreLingo scripts (quick start)

These files are meant to live in your fork repo under:

- data/course-script/
- data/course-json/
- data/course-img/   (your images; for now you already have transparent.png)

## 0) One-time local bootstrap

From the repo root:

    python3 data/course-script/ll01_bootstrap_local.py --repo . --with-venv

## 1) Edit your course spec JSON

Edit:

    data/course-json/jp_minicourse.json

Rules:
- If `ja` contains spaces, the item is treated as a Phrase.
- If `ja` contains no spaces, the item is treated as a Word.
- `image` can be absolute, `~/...`, or relative to the repo root.

## 2) Generate/update YAML course

    python3 data/course-script/ll02_generate_course_from_json.py --repo . --spec data/course-json/jp_minicourse.json --prune-course

This writes:
- courses/<course_slug>/course.yaml
- courses/<course_slug>/<category>/module.yaml
- courses/<course_slug>/<category>/skills/<lesson>.yaml
and imports images into:
- apps/web/static/images/

## 3) Export YAML -> JSON for the dev server

    python3 data/course-script/ll03_export_courses_to_web.py --repo . --spec data/course-json/jp_minicourse.json --ensure-venv --clean

This writes exported JSON here:
- apps/web/src/courses/<course_slug>/

## 4) Start the web app

    npm run web-serve

Then open:
- http://localhost:5173/

Your course should appear in the home listing, or you can try:
- http://localhost:5173/course/<course_slug>

## Updating content

Edit the JSON spec, then re-run steps 2 and 3. That's it.
